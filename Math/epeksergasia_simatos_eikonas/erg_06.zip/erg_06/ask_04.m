num = [1 -1 0 ] ; 
den = [1 -1 0.5];
[r,p,k] = residuez(num,den)
