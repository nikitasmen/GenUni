num = [2 7 0 ]; 
den = [1 1 -2];
[r, p, k] = residuez(num,den)