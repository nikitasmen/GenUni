num = [ 1 0 ];
den = [1 -9/10];

zplane(num,den)