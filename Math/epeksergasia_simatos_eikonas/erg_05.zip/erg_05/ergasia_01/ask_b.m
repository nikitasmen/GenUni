num = [1 0];
den = [1 -9/10];

z = roots(num);
p = roots(den);

zplane(z,p)