z = [0]; 
p = [9/10] ;

zplane(z,p)
