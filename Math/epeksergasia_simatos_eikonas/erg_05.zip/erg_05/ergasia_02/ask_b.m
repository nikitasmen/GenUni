num = [5 0 0];
den = [1 -17/15 4/15];

z = roots(num);
p = roots(den);

zplane(z,p)
