z = [0 0]';
p = [1/3 4/5]';

zplane(z,p)
